"""Tests for providers module."""
